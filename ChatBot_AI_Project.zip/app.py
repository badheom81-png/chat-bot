from flask import Flask, render_template, request, jsonify
import os
import urllib.request
import json

app = Flask(__name__)

# Optional: set GEMINI_API_KEY as an environment variable to enable AI responses.
# Without a key, the chatbot uses a simple built-in demo response system.
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "").strip()

def demo_reply(message):
    text = message.lower().strip()

    if any(word in text for word in ["hello", "hi", "hey", "namaste"]):
        return "Hi there! 👋 I'm ChatBot AI. What would you like to learn today?"
    if "your name" in text or "who are you" in text:
        return "I'm ChatBot AI, a student project built with HTML, CSS, JavaScript, and Python."
    if "python" in text:
        return "Python is a beginner-friendly programming language used in web development, automation, data science, and AI."
    if "html" in text:
        return "HTML structures a webpage. CSS styles it, and JavaScript adds interactive behaviour."
    if "css" in text:
        return "CSS controls the appearance of a webpage, including colours, layouts, spacing, and responsive design."
    if "javascript" in text or "java script" in text:
        return "JavaScript makes websites interactive—for example, handling button clicks and sending chat messages."
    if "machine learning" in text or " ai " in f" {text} ":
        return "Artificial intelligence helps computer systems perform tasks such as understanding language, recognising patterns, and generating responses."
    if "help" in text:
        return "I can answer basic questions about programming and this demo project. Try asking me about Python, HTML, CSS, or JavaScript."
    if "thank" in text:
        return "You're welcome! 😊 Ask me another question whenever you're ready."
    return ("Thanks for your question! This starter version uses a small set of built-in responses. "
            "To get broader AI-generated answers, configure a Gemini API key in the GEMINI_API_KEY environment variable.")

def ai_reply(message):
    """Use Gemini REST API if an API key is configured; otherwise use demo replies."""
    if not GEMINI_API_KEY:
        return demo_reply(message)

    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        "gemini-2.5-flash:generateContent?key=" + GEMINI_API_KEY
    )
    payload = {
        "contents": [{"parts": [{"text": (
            "You are ChatBot AI, a friendly educational assistant created by students. "
            "Give clear, concise, beginner-friendly answers. User message: " + message
        )}]}]
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            result = json.loads(response.read().decode("utf-8"))
        return result["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        app.logger.exception("AI API request failed")
        return "I couldn't reach the AI service just now. Please try again in a moment."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"reply": "Please type a message first."}), 400
    if len(message) > 4000:
        return jsonify({"reply": "Please keep your message under 4,000 characters."}), 400
    return jsonify({"reply": ai_reply(message)})

if __name__ == "__main__":
    app.run(debug=True)
