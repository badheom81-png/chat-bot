# ChatBot AI — Student Project

A responsive chatbot starter built with HTML, CSS, JavaScript, and Python Flask.

## What works now
- Responsive chat interface
- Message sending through JavaScript `fetch`
- Python Flask `/chat` endpoint
- Built-in demo responses for common questions
- Optional Gemini API integration via environment variable

## Run locally (Windows)
1. Install Python 3.10+ from https://www.python.org/downloads/ and select **Add Python to PATH**.
2. Extract this project folder.
3. Open the folder in VS Code.
4. Open Terminal in VS Code and run:

   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```

5. Open http://127.0.0.1:5000 in your browser.

If `py` is unavailable, try `python` instead. Press Ctrl+C in the terminal to stop the server.

## Enable real AI responses (optional)
Without an API key, the app uses demo responses; it is not a full generative AI chatbot yet.

1. Obtain an API key from Google AI Studio: https://aistudio.google.com/
2. Set it as an environment variable named `GEMINI_API_KEY`. Never paste the key into frontend JavaScript or publish it in GitHub.
3. Restart the app. The Python backend will use Gemini when the key is available.

Windows PowerShell, for the current terminal only:

```powershell
$env:GEMINI_API_KEY="YOUR_API_KEY_HERE"
python app.py
```

Check the provider's current pricing, quotas, and terms before using the API. Do not commit API keys to your repository.

## Deploy online with Render
1. Create a GitHub repository and upload the contents of this project folder.
2. Open https://render.com/ and sign in.
3. Choose **New > Web Service**, connect your GitHub repository, and select the project.
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app`
6. Choose the available plan and deploy. If using real AI, add `GEMINI_API_KEY` under Environment Variables in the Render service settings.
7. After a successful deploy, open the public `onrender.com` URL and test several messages.

Free services can sleep after inactivity. A first visit after sleeping may take some time. Do not add a placeholder URL to the poster as if it were live.

## QR code for your poster
After deployment:
1. Copy the real public URL from Render.
2. Open a trusted QR-code generator or create a QR code locally from that exact URL.
3. Scan the QR code with a phone and confirm it opens the deployed chatbot.
4. Replace the sample website URL and QR code on the poster only after testing.

## Team
- Om Badhe — AD2504
- Radha Ghogare — AD2514
- Shubham Dighe — AD2510
- Aditya Madne — AD2523
- Aditya Kshirsagar — AD2501

## Important
This is a starter student project. Built-in demo responses are rule-based and limited. Optional Gemini integration sends user messages to the configured AI provider; inform users appropriately and avoid entering sensitive personal data.
