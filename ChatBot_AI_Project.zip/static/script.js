const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const messages = document.getElementById("chatMessages");
const sendButton = form.querySelector("button");
const clearButton = document.getElementById("clearChat");
const suggestions = document.getElementById("suggestions");

function addMessage(text, who) {
  const row = document.createElement("div");
  row.className = `message-row ${who === "user" ? "user-row" : "bot-row"}`;
  if (who !== "user") {
    const avatar = document.createElement("div");
    avatar.className = "tiny-avatar";
    avatar.textContent = "✦";
    row.appendChild(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = `bubble ${who === "user" ? "user-bubble" : "bot-bubble"}`;
  bubble.textContent = text; // textContent prevents user messages being interpreted as HTML
  row.appendChild(bubble);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
  return row;
}

async function sendMessage(text) {
  const message = (text || "").trim();
  if (!message) return;
  if (suggestions) suggestions.remove();
  addMessage(message, "user");
  input.value = "";
  input.focus();
  sendButton.disabled = true;
  sendButton.textContent = "…";
  const waiting = addMessage("Thinking…", "bot");
  try {
    const response = await fetch("/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message})
    });
    const data = await response.json();
    waiting.querySelector(".bubble").textContent = data.reply || "Sorry, no response was received.";
    if (!response.ok) waiting.querySelector(".bubble").textContent = data.reply || "Please try again.";
  } catch (error) {
    waiting.querySelector(".bubble").textContent = "Could not connect to the server. Check that the Python app is running and try again.";
  } finally {
    sendButton.disabled = false;
    sendButton.textContent = "➤";
    messages.scrollTop = messages.scrollHeight;
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});
document.querySelectorAll(".suggestion").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.textContent));
});
clearButton.addEventListener("click", () => {
  messages.innerHTML = "";
  const row = document.createElement("div");
  row.className = "message-row bot-row";
  const avatar = document.createElement("div");
  avatar.className = "tiny-avatar";
  avatar.textContent = "✦";
  const bubble = document.createElement("div");
  bubble.className = "bubble bot-bubble";
  bubble.textContent = "Conversation cleared! 👋 What would you like to ask?";
  row.append(avatar, bubble);
  messages.appendChild(row);
});
